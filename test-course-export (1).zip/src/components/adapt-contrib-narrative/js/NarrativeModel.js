import ItemsComponentModel from 'core/js/models/itemsComponentModel';

export default class NarrativeModel extends ItemsComponentModel {}
