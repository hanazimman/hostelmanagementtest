import 'core/js/fixes/img.lazyload';
import 'core/js/fixes/reactHelpers.html';
import 'core/js/fixes/safari.label.click.blur';
