import ThemeView from './themeView';

export default class ThemeComponentView extends ThemeView {

  className() {}

  setCustomStyles() {}

  onRemove() {}

}
