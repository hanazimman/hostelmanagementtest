We heartily welcome contributions to the Adapt project source code and community.  
Here is a list of resources you may find useful:

* [Contributing to the Adapt project documentation](https://github.com/adaptlearning/adapt_framework/wiki/Contributing-to-the-Adapt-Project)
* [The Adapt framework wiki](https://github.com/adaptlearning/adapt_framework/wiki)
* [Gitter chat room](https://gitter.im/adaptlearning/adapt_framework)
* [General GitHub documentation](http://help.github.com/)
* [GitHub pull request documentation](http://help.github.com/send-pull-requests/)
